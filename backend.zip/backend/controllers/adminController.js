import User from "../models/User.js";
import Salary from "../models/Salary.js";


// Get All Employees (role = employee)
export const getEmployees = async (req, res) => {
  try {
    const employees = await User.find({ role: "user" })
      .select("-password")
      .sort({ createdAt: -1 });

    res.json(employees);
  } catch (error) {
    res.status(500).json(error);
  }
};

// Update Salary
export const updateSalary = async (req, res) => {
  try {
    const { salary } = req.body;

    const employee = await User.findByIdAndUpdate(
      req.params.id,
      { salary },
      { new: true }
    ).select("-password");

    res.json(employee);
  } catch (error) {
    res.status(500).json(error);
  }
};

// Delete Employee
export const deleteEmployee = async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: "Employee deleted successfully" });
  } catch (error) {
    res.status(500).json(error);
  }
};

export const updateEmployeeDetails = async (req, res) => {
  try {
    const { salary, department, joiningDate } = req.body;

    const employee = await User.findByIdAndUpdate(
      req.params.id,
      {
        salary,
        department,
        joiningDate
      },
      { new: true }
    ).select("-password");

    res.json(employee);
  } catch (error) {
    res.status(500).json(error);
  }
};



export const generateSalarySlip = async (req, res) => {
  try {
    const employee = await User.findById(req.params.id);

    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    res.json({
      name: employee.name,
      email: employee.email,
      department: employee.department,
      joiningDate: employee.joiningDate,
      salary: employee.salary,
      month: new Date().toLocaleString("default", { month: "long" }),
      year: new Date().getFullYear()
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


export const generateSalary = async (req, res) => {
  try {
    const { employeeId, month, year } = req.body;

    const employee = await User.findById(employeeId);

    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    // Example salary calculation
    const basic = employee.salary;
    const hra = basic * 0.2;
    const pf = basic * 0.1;
    const total = basic + hra - pf;

    const salary = await Salary.create({
      employee: employeeId,
      month,
      year,
      basic,
      hra,
      pf,
      total,
    });

    res.status(201).json(salary);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const checkSalaryStatus = async (req, res) => {
  try {
    const { employeeId, month, year } = req.query;

    const salary = await Salary.findOne({
      employee: employeeId,
      month,
      year,
    });

    if (salary) {
      return res.json({ generated: true });
    }

    res.json({ generated: false });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};