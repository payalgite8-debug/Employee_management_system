import Leave from "../models/Leave.js";

export const applyLeave = async (req, res) => {
  try {
    const { from, to, reason } = req.body;

    const leave = await Leave.create({
      userId: req.user.id,
      from,
      to,
      reason
    });

    res.status(201).json(leave);
  } catch (error) {
    res.status(500).json(error);
  }
};

export const getMyLeaves = async (req, res) => {
  try {
    const leaves = await Leave.find({ userId: req.user.id })
      .sort({ createdAt: -1 });

    res.json(leaves);
  } catch (error) {
    res.status(500).json(error);
  }
};

export const getAllLeaves = async (req, res) => {
  try {
    const leaves = await Leave.find()
      .populate("userId", "name email")
      .sort({ createdAt: -1 });

    res.json(leaves);
  } catch (error) {
    res.status(500).json(error);
  }
};

export const updateLeaveStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const leave = await Leave.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );

    res.json(leave);
  } catch (error) {
    res.status(500).json(error);
  }
};