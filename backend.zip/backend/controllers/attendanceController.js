import Attendance from "../models/Attendance.js";

export const markAttendance = async (req, res) => {
  try {
    const userId = req.user.id;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const existing = await Attendance.findOne({
      userId,
      date: { $gte: today }
    });

    if (existing) {
      return res.status(400).json({ message: "Already marked today" });
    }

    const attendance = await Attendance.create({
      userId,
      status: "Present"
    });

    res.status(201).json(attendance);
  } catch (error) {
    res.status(500).json(error);
  }
};

export const getUserAttendance = async (req, res) => {
  try {
    const userId = req.user.id;

    const records = await Attendance.find({ userId })
      .sort({ date: -1 });

    const totalPresent = records.length;

    res.json({ records, totalPresent });
  } catch (error) {
    res.status(500).json(error);
  }
};

export const getAllAttendance = async (req, res) => {
  try {
    const records = await Attendance.find()
      .populate("userId", "name email")
      .sort({ date: -1 });

    res.json(records);
  } catch (error) {
    res.status(500).json(error);
  }
};