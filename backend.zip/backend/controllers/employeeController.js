import Salary from "../models/Salary.js";
import User from "../models/User.js";

/* ======================
   GET MY PROFILE
====================== */
export const getMyProfile = async (req, res) => {
  const user = await User.findById(req.user.id).select("-password");
  res.json(user);
};

/* ======================
   UPDATE MY PROFILE
====================== */
export const updateMyProfile = async (req, res) => {
  const user = await User.findById(req.user.id);

  if (user) {
    user.name = req.body.name || user.name;
    user.phone = req.body.phone || user.phone;

    const updatedUser = await user.save();
    res.json(updatedUser);
  }
};

/* ======================
   GET MY SALARY
====================== */
export const getMySalary = async (req, res) => {
  const salaries = await Salary.find({ employee: req.user.id });
  res.json(salaries);
};