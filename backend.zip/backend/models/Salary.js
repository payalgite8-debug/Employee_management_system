import mongoose from "mongoose";

const salarySchema = new mongoose.Schema(
  {
    employee: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    month: {
      type: String,
      required: true,
    },
    year: {
      type: Number,
      required: true,
    },
    basic: Number,
    hra: Number,
    pf: Number,
    total: Number,
  },
  { timestamps: true }
);

export default mongoose.model("Salary", salarySchema);