import express from "express";
import {
  getMyProfile,
  updateMyProfile,
  getMySalary
} from "../controllers/employeeController.js";

import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/profile", protect, getMyProfile);
router.put("/profile", protect, updateMyProfile);
router.get("/my-salary", protect, getMySalary);

export default router;