import express from "express";
import {
  getEmployees,
  updateSalary,
  deleteEmployee
} from "../controllers/adminController.js";
import { updateEmployeeDetails } from "../controllers/adminController.js";

import { verifyToken, isAdmin } from "../middleware/authMiddleware.js";
import { generateSalarySlip , checkSalaryStatus} from "../controllers/adminController.js";
import { generateSalary } from "../controllers/adminController.js";
import { protect} from "../middleware/authMiddleware.js";




const router = express.Router();

// Only admin can access
router.get("/employees", verifyToken, isAdmin, getEmployees);
router.put("/salary/:id", verifyToken, isAdmin, updateSalary);
router.delete("/employee/:id", verifyToken, isAdmin, deleteEmployee);
router.put( "/employee/:id",verifyToken,isAdmin,updateEmployeeDetails);
router.get("/salary-slip/:id", verifyToken, isAdmin, generateSalarySlip);
router.post("/generate-salary", protect, isAdmin, generateSalary);
router.get("/salary-status",protect,isAdmin,checkSalaryStatus);
export default router;