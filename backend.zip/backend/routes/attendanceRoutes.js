import express from "express";
import { markAttendance } from "../controllers/attendanceController.js";
import { verifyToken } from "../middleware/authMiddleware.js";
import { getUserAttendance } from "../controllers/attendanceController.js";
import { getAllAttendance } from "../controllers/attendanceController.js";
import { isAdmin } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/mark", verifyToken, markAttendance);
router.get("/my", verifyToken, getUserAttendance);
router.get("/all", verifyToken, isAdmin, getAllAttendance);

export default router;