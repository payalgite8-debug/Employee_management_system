import DashboardLayout from "../layouts/DashboardLayout";
import "../styles/cards.css";
import { useNavigate } from "react-router-dom";

function AdminDashboard() {
  const navigate = useNavigate();

  return (
    <DashboardLayout>
      <div className="dashboard-header">
        <h1>Admin Dashboard 👑</h1>
        <p>Overview of system management.</p>
      </div>

      <div className="card-grid">
        <div
          className="dashboard-card blue"
          onClick={() => navigate("/employees")}
        >
          <h3>Total Employees</h3>
          <p>View and manage employees.</p>
        </div>

        <div
          className="dashboard-card green"
          onClick={() => navigate("/attendance")}
        >
          <h3>Attendance Reports</h3>
          <p>Monitor employee attendance.</p>
        </div>

        <div
          className="dashboard-card purple"
          onClick={() => navigate("/admin/leaves")}
        >
          <h3>Leave Requests</h3>
          <p>Approve or reject leave applications.</p>
        </div>

        <div
          className="dashboard-card orange"
         onClick={() => navigate("/admin/salary-management")}
        >
          <h3>Salary Management</h3>
          <p>Manage salary and payroll records.</p>
        </div>
      </div>
    </DashboardLayout>
  );
}

export default AdminDashboard;