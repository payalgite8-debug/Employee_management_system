import { useEffect, useState } from "react";
import axios from "axios";
import "./EmployeeProfile.css";

function EmployeeProfile() {
  const [user, setUser] = useState({});
  const token = localStorage.getItem("token");

  const fetchProfile = async () => {
    const res = await axios.get(
      "http://localhost:5000/api/employee/profile",
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    setUser(res.data);
  };

const updateProfile = async () => {
  const res = await axios.put(
    "http://localhost:5000/api/employee/profile",
    user,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );

  alert("Profile Updated Successfully");

  // 🔥 Important Line
  localStorage.setItem("name", res.data.name);

  // optional: reload page to reflect in header
  window.location.reload();
};
  useEffect(() => {
    fetchProfile();
  }, []);

  return (
    <div className="profile-container">
      <div className="profile-card">
        <h2>My Profile</h2>

        <label>Name</label>
        <input
          value={user.name || ""}
          onChange={(e) => setUser({ ...user, name: e.target.value })}
        />

        <label>Email</label>
        <input value={user.email || ""} disabled />

        <label>Phone</label>
        <input
          value={user.phone || ""}
          onChange={(e) => setUser({ ...user, phone: e.target.value })}
        />

        <button onClick={updateProfile}>Update Profile</button>
      </div>
    </div>
  );
}

export default EmployeeProfile;