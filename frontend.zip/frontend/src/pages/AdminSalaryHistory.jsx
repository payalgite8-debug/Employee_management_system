import { useEffect, useState } from "react";
import DashboardLayout from "../layouts/DashboardLayout";
import { getEmployees } from "../services/adminService";
import axios from "axios";
import "./AdminSalaryHistory.css";

function AdminSalaryHistory() {
  const [employees, setEmployees] = useState([]);

  const fetchEmployees = async () => {
    const res = await getEmployees();
    setEmployees(res.data);
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

const checkSalaryStatus = async () => {
  const token = localStorage.getItem("token");

  const month = new Date().toLocaleString("default", { month: "long" });
  const year = new Date().getFullYear();

  const statusObj = {};

  for (let emp of employees) {
    const res = await axios.get(
      `http://localhost:5000/api/admin/salary-status?employeeId=${emp._id}&month=${month}&year=${year}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    statusObj[emp._id] = res.data.generated;
  }

  setSalaryStatus(statusObj);
};

  const [salaryStatus, setSalaryStatus] = useState({});
  const handleGenerateSalary = async (employeeId) => {
  try {
    const token = localStorage.getItem("token");

    await axios.post(
      "http://localhost:5000/api/admin/generate-salary",
      {
        employeeId,
        month: new Date().toLocaleString("default", { month: "long" }),
        year: new Date().getFullYear(),
      },
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    alert("Salary Generated Successfully ✅");
  } catch (error) {
    alert(error.response?.data?.message || "Error generating salary");
  }
};

  return (
    <DashboardLayout>
      <h1>Salary Management</h1>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Department</th>
              <th>Salary</th>
              <th>Month</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((emp) => (
              <tr key={emp._id}>
                <td>{emp.name}</td>
                <td>{emp.department || "-"}</td>
                <td>Rs. {emp.salary || 0}</td>
              <td>
                  {new Date().toLocaleString("default", {
                    month: "long",
                  })}{" "}
                  {new Date().getFullYear()}
                </td>
                <td>
                             <button
  onClick={() => handleGenerateSalary(emp._id)}
  disabled={salaryStatus[emp._id]}
>
  {salaryStatus[emp._id] ? "Generated ✅" : "Generate Salary"}
</button>
 </td>
    
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}

export default AdminSalaryHistory;