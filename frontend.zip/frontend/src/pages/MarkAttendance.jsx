import { useState, useEffect } from "react";
import DashboardLayout from "../layouts/DashboardLayout";
import { markAttendance, getMyAttendance } from "../services/attendanceService";
import "../styles/table.css";

function MarkAttendance() {
  const [message, setMessage] = useState("");
  const [records, setRecords] = useState([]);
  const [total, setTotal] = useState(0);

  const fetchAttendance = async () => {
    try {
      const res = await getMyAttendance();
      setRecords(res.data.records);
      setTotal(res.data.totalPresent);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    fetchAttendance();
  }, []);

  const handleMark = async () => {
    try {
      await markAttendance();
      setMessage("✅ Attendance marked successfully!");
      fetchAttendance();
    } catch (err) {
      setMessage(err.response?.data?.message || "Error marking attendance");
    }
  };

  return (
    <DashboardLayout>
      <h1>Mark Attendance</h1>

      <div style={{ marginTop: "20px" }}>
        <button
          onClick={handleMark}
          className="primary-btn"
        >
          Mark Present
        </button>

        {message && <p className="msg">{message}</p>}
      </div>

      <div className="attendance-summary">
        <h3>Total Present Days: {total}</h3>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {records.map((item) => (
              <tr key={item._id}>
                <td>{new Date(item.date).toLocaleDateString()}</td>
                <td className="status">{item.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}

export default MarkAttendance;