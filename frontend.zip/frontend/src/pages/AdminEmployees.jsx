import { useEffect, useState } from "react";
import DashboardLayout from "../layouts/DashboardLayout";
import {
  getEmployees,
  updateEmployeeDetails,
  deleteEmployee,
  getSalarySlip
} from "../services/adminService";
import "../styles/table.css";
import jsPDF from "jspdf";

function AdminEmployees() {
  const [employees, setEmployees] = useState([]);
  const [editingId, setEditingId] = useState(null);

  const [form, setForm] = useState({
    salary: "",
    department: "",
    joiningDate: ""
  });

  const fetchEmployees = async () => {
    const res = await getEmployees();
    setEmployees(res.data);
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const handleEditClick = (emp) => {
    setEditingId(emp._id);
    setForm({
      salary: emp.salary || "",
      department: emp.department || "",
      joiningDate: emp.joiningDate
        ? emp.joiningDate.split("T")[0]
        : ""
    });
  };

  const handleSave = async (id) => {
    await updateEmployeeDetails(id, form);
    setEditingId(null);
    fetchEmployees();
  };

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm("Are you sure?");
    if (!confirmDelete) return;

    await deleteEmployee(id);
    fetchEmployees();
  };

  // ✅ NEW FUNCTION - Generate Salary Slip
const handleGenerateSlip = async (id) => {
  try {
    const res = await getSalarySlip(id);
    const data = res.data;

    const salary = Number(data.salary || 0);

    const doc = new jsPDF();

     const img = "/logo.png";
    doc.addImage(img, "PNG", 20, 10, 30, 20);


    // Company Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(22);
    doc.text("INFINITE PVT LTD", 105, 20, { align: "center" });

    doc.setFontSize(16);
    doc.text("Salary Slip", 105, 30, { align: "center" });

    doc.setLineWidth(0.5);
    doc.line(20, 35, 190, 35);

    // Employee Info Box
    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);

    let startY = 50;

    doc.text("Employee Name:", 25, startY);
    doc.text(data.name, 90, startY);

    startY += 10;
    doc.text("Email:", 25, startY);
    doc.text(data.email, 90, startY);

    startY += 10;
    doc.text("Department:", 25, startY);
    doc.text(data.department || "-", 90, startY);

    startY += 10;
    doc.text("Joining Date:", 25, startY);
    doc.text(
      data.joiningDate
        ? new Date(data.joiningDate).toLocaleDateString()
        : "-",
      90,
      startY
    );

    startY += 10;
    doc.text("Month:", 25, startY);
    doc.text(data.month + " " + data.year, 90, startY);

    doc.line(20, startY + 10, 190, startY + 10);

    // Salary Box
    startY += 25;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(14);
    doc.text("Total Salary", 25, startY);

    doc.setFontSize(18);
    doc.text("Rs. " + salary.toLocaleString("en-IN"), 150, startY, {
      align: "right",
    });

    // Footer
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");

    doc.line(130, 260, 180, 260);
    doc.text("Authorized Signature", 130, 270);

    doc.save(data.name + "_SalarySlip.pdf");
  } catch (error) {
    console.error(error);
    alert("Error generating salary slip");
  }
};
  return (
    <DashboardLayout>
      <h1>Employees Management</h1>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Department</th>
              <th>Joining Date</th>
              <th>Salary</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {employees.map((emp) => (
              <tr key={emp._id}>
                <td>{emp.name}</td>
                <td>{emp.email}</td>

                {/* Department */}
                <td>
                  {editingId === emp._id ? (
                    <input
                      type="text"
                      value={form.department}
                      onChange={(e) =>
                        setForm({ ...form, department: e.target.value })
                      }
                    />
                  ) : (
                    emp.department || "-"
                  )}
                </td>

                {/* Joining Date */}
                <td>
                  {editingId === emp._id ? (
                    <input
                      type="date"
                      value={form.joiningDate}
                      onChange={(e) =>
                        setForm({ ...form, joiningDate: e.target.value })
                      }
                    />
                  ) : emp.joiningDate ? (
                    new Date(emp.joiningDate).toLocaleDateString()
                  ) : (
                    "-"
                  )}
                </td>

                {/* Salary */}
                <td>
                  {editingId === emp._id ? (
                    <input
                      type="number"
                      value={form.salary}
                      onChange={(e) =>
                        setForm({ ...form, salary: e.target.value })
                      }
                    />
                  ) : (
                    `₹ ${emp.salary || 0}`
                  )}
                </td>

                {/* Actions */}
                <td>
                  {editingId === emp._id ? (
                    <button
                      onClick={() => handleSave(emp._id)}
                      className="approve-btn"
                    >
                      Save
                    </button>
                  ) : (
                    <button
                      onClick={() => handleEditClick(emp)}
                      className="primary-btn"
                    >
                      Edit
                    </button>
                  )}

                  <button
                    onClick={() => handleDelete(emp._id)}
                    className="reject-btn"
                    style={{ marginLeft: "8px" }}
                  >
                    Delete
                  </button>

                  {/* ✅ Salary Slip Button */}
                  <button
                    onClick={() => handleGenerateSlip(emp._id)}
                    className="primary-btn"
                    style={{ marginLeft: "8px" }}
                  >
                    Salary Slip
                  </button>
                </td>
              </tr>
            ))}

            {employees.length === 0 && (
              <tr>
                <td colSpan="6" style={{ textAlign: "center" }}>
                  No employees found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}

export default AdminEmployees;