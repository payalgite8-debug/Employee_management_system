import DashboardLayout from "../layouts/DashboardLayout";
import "../styles/cards.css";
import { useNavigate } from "react-router-dom";

function UserDashboard() {
  const user = JSON.parse(localStorage.getItem("user"));
  const navigate = useNavigate();

  return (
    <DashboardLayout>
      <div className="dashboard-header">
        <h1>
          Welcome back, <span className="highlight-name">{user?.name}</span> 👋
        </h1>
        <p>Here’s your activity overview.</p>
      </div>

      <div className="card-grid">
        <div
          className="dashboard-card blue"
          onClick={() => navigate("/mark-attendance")}
        >
          <h3>Mark Attendance</h3>
          <p>Mark your daily attendance quickly.</p>
        </div>

        <div
          className="dashboard-card green"
          onClick={() => navigate("/apply-leave")}
        >
          <h3>Apply Leave</h3>
          <p>Submit leave request for approval.</p>
        </div>

        <div
          className="dashboard-card purple"
          onClick={() => navigate("/my-salary")}
        >
          <h3>Salary Slip</h3>
          <p>View and download salary details.</p>
        </div>

        <div
          className="dashboard-card orange"
          onClick={() => navigate("/profile")}
        >
          <h3>My Profile</h3>
          <p>Manage your personal information.</p>
        </div>
      </div>
    </DashboardLayout>
  );
}

export default UserDashboard;