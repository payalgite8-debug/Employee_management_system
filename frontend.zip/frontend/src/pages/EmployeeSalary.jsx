import { useEffect, useState } from "react";
import axios from "axios";
import jsPDF from "jspdf";
import "./EmployeeSalary.css";


function EmployeeSalary() {
  const [salaries, setSalaries] = useState([]);

  const fetchSalary = async () => {
    const token = localStorage.getItem("token");

    const res = await axios.get(
      "http://localhost:5000/api/employee/my-salary",
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    setSalaries(res.data);
  };

  useEffect(() => {
    fetchSalary();
  }, []);

  const downloadSlip = (salary) => {
    const doc = new jsPDF();

    doc.setFontSize(18);
    doc.text("Salary Slip", 80, 20);

    doc.setFontSize(12);
    doc.text(`Month: ${salary.month} ${salary.year}`, 20, 40);
    doc.text(`Basic: Rs. ${salary.basic}`, 20, 55);
    doc.text(`HRA: Rs. ${salary.hra}`, 20, 65);
    doc.text(`PF: Rs. ${salary.pf}`, 20, 75);
    doc.text(`Total: Rs. ${salary.total}`, 20, 90);

    doc.save(`Salary_${salary.month}.pdf`);
  };

  return (
    <div className="salary-container">
      <h2>My Salary</h2>

      {salaries.length === 0 ? (
        <p className="no-data">No salary records found</p>
      ) : (
        <div className="salary-grid">
          {salaries.map((sal) => (
            <div key={sal._id} className="salary-card">
              <h3>{sal.month} {sal.year}</h3>

              <p><strong>Basic:</strong> ₹ {sal.basic}</p>
              <p><strong>HRA:</strong> ₹ {sal.hra}</p>
              <p><strong>PF:</strong> ₹ {sal.pf}</p>
              <p className="total"><strong>Total:</strong> ₹ {sal.total}</p>

              <button onClick={() => downloadSlip(sal)}>
                Download Slip
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default EmployeeSalary;