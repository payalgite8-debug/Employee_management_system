import { useEffect, useState } from "react";
import DashboardLayout from "../layouts/DashboardLayout";
import { getAllLeaves, updateLeaveStatus } from "../services/leaveService";
import "../styles/table.css";

function AdminLeaves() {
  const [leaves, setLeaves] = useState([]);

  const fetchLeaves = async () => {
    const res = await getAllLeaves();
    setLeaves(res.data);
  };

  useEffect(() => {
    fetchLeaves();
  }, []);

  const handleStatus = async (id, status) => {
    await updateLeaveStatus(id, status);
    fetchLeaves();
  };

  return (
    <DashboardLayout>
      <h1>Leave Requests</h1>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Employee</th>
              <th>From</th>
              <th>To</th>
              <th>Reason</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {leaves.map((leave) => (
              <tr key={leave._id}>
                <td>{leave.userId?.name}</td>
                <td>{new Date(leave.from).toLocaleDateString()}</td>
                <td>{new Date(leave.to).toLocaleDateString()}</td>
                <td>{leave.reason}</td>
                <td>{leave.status}</td>
                <td>
                  {leave.status === "Pending" && (
                    <>
                      <button
                        onClick={() => handleStatus(leave._id, "Approved")}
                        className="approve-btn"
                      >
                        Approve
                      </button>

                      <button
                        onClick={() => handleStatus(leave._id, "Rejected")}
                        className="reject-btn"
                      >
                        Reject
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}

export default AdminLeaves;