import { useState, useEffect } from "react";
import DashboardLayout from "../layouts/DashboardLayout";
import { applyLeave, getMyLeaves } from "../services/leaveService";
import "../styles/table.css";

function ApplyLeave() {
  const [form, setForm] = useState({
    from: "",
    to: "",
    reason: ""
  });

  const [leaves, setLeaves] = useState([]);

  const fetchLeaves = async () => {
    const res = await getMyLeaves();
    setLeaves(res.data);
  };

  useEffect(() => {
    fetchLeaves();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await applyLeave(form);
    setForm({ from: "", to: "", reason: "" });
    fetchLeaves();
  };

  return (
    <DashboardLayout>
      <h1>Apply Leave</h1>

      <form onSubmit={handleSubmit} className="leave-form">
        <input
          type="date"
          value={form.from}
          onChange={(e) => setForm({ ...form, from: e.target.value })}
          required
        />

        <input
          type="date"
          value={form.to}
          onChange={(e) => setForm({ ...form, to: e.target.value })}
          required
        />

        <input
          type="text"
          placeholder="Reason"
          value={form.reason}
          onChange={(e) => setForm({ ...form, reason: e.target.value })}
          required
        />

        <button className="primary-btn">Apply</button>
      </form>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>From</th>
              <th>To</th>
              <th>Reason</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {leaves.map((leave) => (
              <tr key={leave._id}>
                <td>{new Date(leave.from).toLocaleDateString()}</td>
                <td>{new Date(leave.to).toLocaleDateString()}</td>
                <td>{leave.reason}</td>
                <td>{leave.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}

export default ApplyLeave;