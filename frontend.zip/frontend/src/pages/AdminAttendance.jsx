import { useEffect, useState } from "react";
import DashboardLayout from "../layouts/DashboardLayout";
import { getAllAttendance } from "../services/attendanceService";
import "../styles/table.css";

function AdminAttendance() {
  const [records, setRecords] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState("");
  const [dateFilter, setDateFilter] = useState("");

  const fetchData = async () => {
    try {
      const res = await getAllAttendance();
      setRecords(res.data);
      setFiltered(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    let data = records;

    // Search by name
    if (search) {
      data = data.filter((item) =>
        item.userId?.name.toLowerCase().includes(search.toLowerCase())
      );
    }

    // Filter by date
    if (dateFilter) {
      data = data.filter(
        (item) =>
          new Date(item.date).toLocaleDateString() ===
          new Date(dateFilter).toLocaleDateString()
      );
    }

    setFiltered(data);
  }, [search, dateFilter, records]);

  return (
    <DashboardLayout>
      <h1>Attendance Report</h1>

      {/* Filters Section */}
      <div className="filter-container">
        <input
          type="text"
          placeholder="Search by employee name..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <input
          type="date"
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
        />
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Employee Name</th>
              <th>Email</th>
              <th>Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length > 0 ? (
              filtered.map((item) => (
                <tr key={item._id}>
                  <td>{item.userId?.name}</td>
                  <td>{item.userId?.email}</td>
                  <td>{new Date(item.date).toLocaleDateString()}</td>
                  <td className="status">{item.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" style={{ textAlign: "center" }}>
                  No records found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}

export default AdminAttendance;