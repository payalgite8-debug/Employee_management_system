import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api"
});

API.interceptors.request.use((req) => {
  req.headers.Authorization = localStorage.getItem("token");
  return req;
});

export const markAttendance = () => API.post("/attendance/mark");
export const getMyAttendance = () => API.get("/attendance/my");
export const getAllAttendance = () => API.get("/attendance/all");