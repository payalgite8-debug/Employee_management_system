import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api"
});

API.interceptors.request.use((req) => {
  req.headers.Authorization = localStorage.getItem("token");
  return req;
});

export const getEmployees = () =>
  API.get("/admin/employees");

export const updateSalary = (id, salary) =>
  API.put(`/admin/salary/${id}`, { salary });

export const deleteEmployee = (id) =>
  API.delete(`/admin/employee/${id}`);

export const updateEmployeeDetails = (id, data) =>
  API.put(`/admin/employee/${id}`, data);

export const getSalarySlip = (id) =>
  API.get(`/admin/salary-slip/${id}`);