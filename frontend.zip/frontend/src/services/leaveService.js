import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api"
});

API.interceptors.request.use((req) => {
  req.headers.Authorization = localStorage.getItem("token");
  return req;
});

export const applyLeave = (data) => API.post("/leave/apply", data);
export const getMyLeaves = () => API.get("/leave/my");
export const getAllLeaves = () => API.get("/leave/all");
export const updateLeaveStatus = (id, status) =>
  API.put(`/leave/update/${id}`, { status });