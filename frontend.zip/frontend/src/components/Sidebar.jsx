import { Link, useLocation } from "react-router-dom";

function Sidebar() {
  const user = JSON.parse(localStorage.getItem("user"));
  const location = useLocation();

  const isActive = (path) => location.pathname === path ? "active" : "";

  return (
    <div className="sidebar">
      <h2 className="logo">EMS</h2>

      {user?.role === "admin" && (
        <>
          <Link className={isActive("/admin")} to="/admin">Dashboard</Link>
          <Link className={isActive("/employees")} to="/employees">Employees</Link>
          <Link className={isActive("/attendance")} to="/attendance">Attendance</Link>
           <Link className={isActive("/admin/leaves")} to="/admin/leaves">Leave Request</Link>
          <Link className={isActive("/admin/salary-management")} to="/admin/salary-management">Salary</Link>
        </>
      )}

      {user?.role === "user" && (
        <>
          <Link className={isActive("/user")} to="/user">Dashboard</Link>
          <Link className={isActive("/mark-attendance")} to="/mark-attendance">Mark Attendance</Link>
          <Link className={isActive("/apply-leave")} to="/apply-leave">Apply Leave</Link>
          <Link className={isActive("/my-salary")} to="/my-salary">Salary Slip</Link>
          <Link className={isActive("/profile")} to="/profile">Profile</Link>
     


        </>
      )}
    </div>
  );
}

export default Sidebar;