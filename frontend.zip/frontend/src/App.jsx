import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AdminDashboard from "./pages/AdminDashboard";
import UserDashboard from "./pages/UserDashboard";
import ProtectedRoute from "./components/ProtectedRoute";
import MarkAttendance from "./pages/MarkAttendance";
import AdminAttendance from "./pages/AdminAttendance";
import ApplyLeave from "./pages/ApplyLeave";
import AdminLeaves from "./pages/AdminLeaves";
import AdminEmployees from "./pages/AdminEmployees";
import AdminSalaryHistory from "./pages/AdminSalaryHistory";
import EmployeeSalary from "./pages/EmployeeSalary";
import EmployeeProfile from "./pages/EmployeeProfile";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admin" element={<ProtectedRoute role="admin"><AdminDashboard /></ProtectedRoute>} />
      <Route path="/user" element={<ProtectedRoute role="user"><UserDashboard /></ProtectedRoute>}/>
      <Route path="/mark-attendance" element={<MarkAttendance />} />
      <Route path="/attendance" element={<AdminAttendance />} />
      <Route path="/apply-leave" element={<ApplyLeave/>} />
      <Route path="/admin/leaves" element={<AdminLeaves />} />
      <Route path="/employees" element={<AdminEmployees/>} />
      <Route path="/admin/salary-management" element={<AdminSalaryHistory />} />
      <Route path="/my-salary" element={<EmployeeSalary/>} />
      <Route path="/profile" element={<EmployeeProfile/>} />
          </Routes>
    </BrowserRouter>
  );
}

export default App;